-- AlterTable
ALTER TABLE `mail_message_log` ADD COLUMN `toAddresses` TEXT NULL;
